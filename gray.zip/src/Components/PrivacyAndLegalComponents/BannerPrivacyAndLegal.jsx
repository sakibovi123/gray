import React from "react";

const BannerPrivacyAndLegal = () => {
  return(
    <div className={"h-[200px] w-full bg-gray-200 flex justify-center items-center text-2xl font-semibold text-slate-800 sm:text-4xl md:text-5xl"}>
      <p>
        GGLink TERMS OF SERVICE
      </p>
    </div>
  );
};

export default BannerPrivacyAndLegal;