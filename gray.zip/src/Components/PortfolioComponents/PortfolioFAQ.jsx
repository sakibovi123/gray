import React from "react";

const PortfolioFAQ = ()=> {



    return (
        <div className="container mx-auto w-[60%]">
            
            
        </div>
    )
}

export default PortfolioFAQ